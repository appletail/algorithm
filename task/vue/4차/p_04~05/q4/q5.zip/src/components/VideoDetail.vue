<template>
  <div class="detail">
    <h4>{{ youtubeTitle }}</h4>
    <p>{{ youtubeDescription }}</p>
  </div>
</template>

<script>
export default {
  name: 'VideoDetail',
  props: {
    youtubeTitle: String,
    youtubeDescription: String,
  }
}
</script>

<style scoped>
  .detail{
    width: 856px;
    border: 1px solid rgb(201, 197, 197);
  }
</style>