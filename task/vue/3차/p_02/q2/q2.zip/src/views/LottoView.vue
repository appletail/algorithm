<template>
  <div class="lotto">
    <h1>로또</h1>
    <button @click="luckyNumbers">Get Lucky Numbers</button>
    <p>{{ sevenNumbers }}</p>
  </div>
</template>

<script>
import _ from 'lodash'

export default {
  name: 'LottoView',
  data() {
    return {
      sevenNumbers: [],
    }
  },
  methods: {
    luckyNumbers() {
      const tmpArr = []
      while (tmpArr.length < 6) {
        const tmp = _.random(1, 45)
        if (!tmpArr.includes(tmp)) {
          tmpArr.push(tmp)
        }
      }

      this.sevenNumbers = tmpArr
    }
  }
}
</script>

<style>

</style>