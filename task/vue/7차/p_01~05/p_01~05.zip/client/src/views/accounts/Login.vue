<template>
  <div></div>
</template>

<script>
// import axios from 'axios'

export default {
  name: 'Login',
  data: function () {
    return {}
  },
  methods: {
    login: function () {
      
    }
  }
}
</script>
