<template>
  <div id="app">
    <h1 style="color: rgb(0, 110, 255);">SSAFY TUBE</h1>
    <iframe id="player" type="text/html" width="640" height="360"
    :src="`http://www.youtube.com/embed/${youtubeVideo}`"
    frameborder="0"></iframe><br>
    <div class="youtubeTitle d-flex">
      {{ youtubeTitle }}
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'App',
  components: {

  },
  data() {
    return {
      youtubeVideo: null,
      youtubeTitle: null
    }
  },
  methods: {
    youtubeInit() {
      axios({
        method: 'get',
        url: 'https://www.googleapis.com/youtube/v3/search',
        params: {
          key: 'AIzaSyAAVXLpwBT6dkStlj18x7Z6XKQ6kI0enPo',
          part: 'snippet',
          type: 'video',
          q: '코딩노래',
        }
      })
        .then((response) => {
          this.youtubeVideo = response.data.items[0].id.videoId
          this.youtubeTitle = response.data.items[0].snippet.title
        })
        .catch((error) => {
          console.log(error)
        })
    },
  },
  created() {
    this.youtubeInit()
  },
}
</script>

<style>
#app {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.youtubeTitle{
  width: 640px;
  height: 50px;
  border: solid 1px rgb(201, 197, 197);
  display: flex;
  font-size: 20px;
  margin: 0.5% auto;
  align-items: center;
  justify-content: center;
  box-shadow: 0 15px 18px -15px rgb(155, 155, 155);
}
</style>
